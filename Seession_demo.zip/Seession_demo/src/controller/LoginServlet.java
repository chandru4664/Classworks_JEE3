package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final Logger log = Logger.getLogger("LoginServlet");
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("uname");
		String password = request.getParameter("password");
		
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		
		if(password.equals("admin@123"))
		{
		
		HttpSession session=request.getSession(true);
		
		session.setAttribute("username",username );
		log.info("seesion id"+session.getId());
		
		
		
		String bookURL = response.encodeURL("Bookticket");
		String cancelURL = response.encodeURL("Cancelticket");
		String logoutURL = response.encodeURL("Logout");
		
		pw.println("<h2> Hello! " + username + "</h2>");
		pw.println("<a href='" + bookURL + "'>Book Ticket</a> <br/><br/>");
		pw.println("<a href='" + cancelURL + "'>Cancel Ticket</a><br/><br/>");
		pw.println("<a href='" + logoutURL + "'> Logout</a><br/><br/>");
	}
	else{
		pw.println("<h2> Hello! " + username + "</h2>");
		pw.println("Invalid Credentials");
		pw.println("<h2><a href='login.html'>Login Again</a></h2>");
		
	}
		
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
