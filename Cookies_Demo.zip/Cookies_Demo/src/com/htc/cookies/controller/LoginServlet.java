package com.htc.cookies.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//request.getRequestDispatcher("index.html").include(request, response);
		
		String username=request.getParameter("usertxt");
		String password=request.getParameter("passtxt");
		if(password.equals("admin@123"))
		{
			out.println("login successfull");
			Cookie ck=new Cookie("name",username);
			response.addCookie(ck);
			out.println("Login successfull");
			
		}
		else
		{
			out.println("sorry invalid pasword");

request.getRequestDispatcher("Login.html").include(request, response);
		}
		out.println("<br/>");
		out.println("<br/>");
		out.println("<br/>");
		out.println("<br/>");
		
		request.getRequestDispatcher("link.html").include(request, response);
	}

	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
