package com.htc.corejava.day8.loggingsample;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggerDemo {

	public static void main(String[] args) {
		Logger logger=Logger.getLogger(LoggerDemo.class.getName());
		
		logger.fine("Fine log msg");
		logger.finer("finer error");
		logger.finest("finest bug");
		
		logger.info("Data is saved");
		logger.config("Your object is ready");
		logger.warning("Please initialize the variable");
		logger.severe("Sorry program will terminate now");
	
		logger.log(Level.INFO, "message");
		
	}
}
