package com.htc.aptraining.loggers;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggerDemo {

	public static void main(String[] args) {
		
		System.setProperty("java.util.logging.config.file" , "src/mylogging.properties");
		
		Logger logger = Logger.getLogger("LoggerDemo");
		logger.log(Level.SEVERE, "Error message");
		logger.log(Level.INFO, "Information message");
		logger.log(Level.WARNING, "warning message");
		logger.log(Level.CONFIG, "Config message");
		logger.log(Level.FINE, "Trace messages");
		
		logger.info("Info message");
		logger.severe("Severe message");
	}
}
