package com.htc.aptraining.loggers;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Log4jDemo {

	public static void main(String[] args) {
		
		Logger logger = LogManager.getLogger(Log4jDemo.class);

	    logger.trace("welcome to log4j ");
	     
	    ForLog4j forLog4j = new ForLog4j();
	    int maxVal = forLog4j.computeMax(4, 8, 6, 32, 21, 12, 64);
	    System.out.println(maxVal);
	    logger.warn("configuration is very important");
		
	}
}
