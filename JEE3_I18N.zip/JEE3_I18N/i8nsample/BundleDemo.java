package com.htc.corejava.day8.i8nsample;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class BundleDemo {

	public static void main(String[] args) {
		
		//Locale.setDefault(Locale.FRANCE);
		ResourceBundle bundle = ResourceBundle.getBundle("MessageResources");
		
		System.out.println(bundle.getString("key1"));
		System.out.println(bundle.getString("welcome"));
		System.out.println(bundle.getString("bye"));
		
	
		System.out.println(MessageFormat.format(bundle.getString("key1"), "Gopi"));
		System.out.println(MessageFormat.format(bundle.getString("welcome"), "Gopi", "118n"));
		System.out.println(MessageFormat.format(bundle.getString("bye"), "Gopi"));
		
	}
}
