package com.htc.corejava.day8.i8nsample;

import java.awt.FlowLayout;
import java.awt.Font;
import java.util.Locale;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class UnicodeDemo extends JFrame{
	public UnicodeDemo(){
		/*
		Amma=\u0B85\u0BAE\u0BCD\u0BAE\u0BBE
		Ashok=\u0B85\u0BC7\u0BB7\u0B95\u0B82
		raj=\u0BB0\u0BBE\u0B9C\u0BCD
		prathivindhan:\u0BAA\u0BBF\u0BB0\u0BA4\u0BBF\u0BB5\u0BBF\u0BA8\u0BCD\u0BA4\u0BA9\u0BCD
*/
		
		
		JLabel label = new JLabel("Your Name");
		JTextField t1 = new JTextField(25);
		//String name = "\u0C10\u0C20\u0C30";  // Anish in Telugu
		//String name="\u0c17\u0C4B\u0C2A\u0C3F"; //Gopi in Telugu
		//String name="\u0B95\u0BC7\u0BBE\u0BAA\u0BBF"; // Gopi in Tamil
		
		t1.setFont(new Font("latha", Font.BOLD, 16));
		t1.setText("\u0BAA\u0BBF\u0BB0\u0BA4\u0BBF\u0BB5\u0BBF\u0BA8\u0BCD\u0BA4\u0BA9\u0BCD");
		
		getContentPane().setLayout(new FlowLayout());
		getContentPane().add(label);
		getContentPane().add(t1);
		
		setVisible(true);
		setSize(500, 500);
		setTitle("Tamil Font");
		
	}
	
	public static void main(String[] args) {
		System.out.println("\u0B85\u0BAE\u0BCD\u0BAE\u0BBE");
		new UnicodeDemo();
		
	}
	

}
