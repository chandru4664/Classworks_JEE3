package com.htc.corejava.day8.i8nsample;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

public class ResourceBundleDemo {
	public static void main(String[] args) throws IOException {
		Locale locale=new Locale("ta","IN");
		
		// ResourceBundle class will look for a resource file in the source files scope
		ResourceBundle rb=ResourceBundle.getBundle("ApplicationResources",locale);
		System.out.println("Name: "+rb.getString("Name"));
		System.out.println("Company: "+rb.getString("company"));
		System.out.println("goodmorning:"+ rb.getString("goodmorning"));
		
		System.out.println("=========");
		
		// Properties class look for a resource file in the project scope
		Properties property=new Properties();
		FileInputStream file=new FileInputStream(new File("myProperty.properties"));
		property.load(file);
		System.out.println("From property file");
		System.out.println("Name:"+property.getProperty("Name"));
		System.out.println("Company:"+property.getProperty("company"));
		System.out.println("goodmorning:"+property.getProperty("goodmorning"));
		
		
	}
	
}
